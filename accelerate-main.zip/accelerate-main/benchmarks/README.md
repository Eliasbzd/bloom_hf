# Benchmarks

The folders below contain suites to test various functionalities in Accelerate.

See their relevant README.md's for more information.
